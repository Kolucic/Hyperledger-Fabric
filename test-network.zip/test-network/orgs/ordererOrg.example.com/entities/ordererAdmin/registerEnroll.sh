#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../../fabric-ca-client
set -x
fabric-ca-client register --id.name ordererAdmin --id.secret ordererAdminpw --caname ca-orderer --id.type admin --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

set -x
fabric-ca-client enroll -u https://ordererAdmin:ordererAdminpw@localhost:9054  -M ../entities/ordererAdmin/msp --tls.certfiles ../fabric-ca-server/tls-cert.pem 
set +x

