#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../../fabric-ca-client
set -x
fabric-ca-client register --id.name orderer --id.secret ordererpw --caname ca-orderer --id.type orderer --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

set -x
fabric-ca-client enroll -u https://orderer:ordererpw@localhost:9054 --csr.hosts orderer.ordererOrg.example.com --csr.hosts localhost -M ../entities/orderer/msp --tls.certfiles ../fabric-ca-server/tls-cert.pem 
set +x

set -x
fabric-ca-client enroll -u https://orderer:ordererpw@localhost:9054 --csr.hosts orderer.ordererOrg.example.com --csr.hosts localhost -M ../entities/orderer/tls --enrollment.profile tls --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

cp ./tls/tlscacerts/*  ./tls/ca.crt
cp ./tls/signcerts/* ./tls/server.crt
cp ./tls/keystore/* ./tls/server.key
mkdir -p ./msp/tlscacerts
cp ./tls/tlscacerts/* ./msp/tlscacerts/tls-localhost-9054-ca-orderer.pem
mkdir ./tls/tlscacerts
cp ./tls/tlscacerts/* ./tls/tlscacerts/tls-localhost-9054-ca-orderer.pem
mkdir ./ca
cp ./msp/cacerts/* ./ca/tls-localhost-9054-ca-orderer.pem

