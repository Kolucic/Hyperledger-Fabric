#!/bin/bash
cd $(dirname $0)
docker-compose -f ./fabric-ca-server/docker-compose.yaml up -d
sleep 2
bash ./script/registerEnroll.sh
bash ./entities/orderer/registerEnroll.sh
bash ./entities/ordererAdmin/registerEnroll.sh
docker-compose -f ./fabric-ca-server/docker-compose.yaml down
bash ./script/connection-profile.sh
