#!/bin/bash
cd $(dirname $0)
#### Joining peers org1.example.com
export CORE_PEER_TLS_ENABLED=true
export FABRIC_CFG_PATH=$PWD/../../
export CORE_PEER_LOCALMSPID="org1-example-com"
export CORE_PEER_MSPCONFIGPATH="$PWD/../org1.example.com/entities/org1admin/msp"
export CORE_PEER_TLS_ROOTCERT_FILE="$PWD/../org1.example.com/entities/peer0/tls/ca.crt"
export CORE_PEER_ADDRESS=localhost:7051
peer channel join -b ./mychannel.block
# ---------------------------------------------
#### Joining peers org2.example.com
export CORE_PEER_TLS_ENABLED=true
export FABRIC_CFG_PATH=$PWD/../../
export CORE_PEER_LOCALMSPID="org2-example-com"
export CORE_PEER_MSPCONFIGPATH="$PWD/../org2.example.com/entities/org2admin/msp"
export CORE_PEER_TLS_ROOTCERT_FILE="$PWD/../org2.example.com/entities/peer0/tls/ca.crt"
export CORE_PEER_ADDRESS=localhost:9051
peer channel join -b ./mychannel.block
# ---------------------------------------------
