#!/bin/bash
cd $(dirname $0)
export CORE_PEER_TLS_ENABLED=true
export FABRIC_CFG_PATH=$PWD/../../
export CORE_PEER_LOCALMSPID="org1-example-com"
export CORE_PEER_MSPCONFIGPATH="$PWD/../org1.example.com/entities/org1admin/msp"
peer channel create -o localhost:7050 -c mychannel --ordererTLSHostnameOverride orderer.ordererOrg.example.com -f ./mychannel.tx --outputBlock ./mychannel.block --tls --cafile $PWD/../ordererOrg.example.com/entities/orderer/tls/ca.crt
#### Adding org1.example.com anchor peers definition to channel block
export CORE_PEER_LOCALMSPID="org1-example-com"
export CORE_PEER_MSPCONFIGPATH="$PWD/../org1.example.com/entities/org1admin/msp"
peer channel update -o localhost:7050 -c mychannel --ordererTLSHostnameOverride orderer.ordererOrg.example.com -f ./org1.example.com-anchor.tx --tls --cafile $PWD/../ordererOrg.example.com/entities/orderer/tls/ca.crt
#### Adding org2.example.com anchor peers definition to channel block
export CORE_PEER_LOCALMSPID="org2-example-com"
export CORE_PEER_MSPCONFIGPATH="$PWD/../org2.example.com/entities/org2admin/msp"
peer channel update -o localhost:7050 -c mychannel --ordererTLSHostnameOverride orderer.ordererOrg.example.com -f ./org2.example.com-anchor.tx --tls --cafile $PWD/../ordererOrg.example.com/entities/orderer/tls/ca.crt
