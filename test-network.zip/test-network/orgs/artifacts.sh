#!/bin/bash
cd $(dirname $0)
bash ./org1.example.com/entities_certs.sh
bash ./org2.example.com/entities_certs.sh
bash ./ordererOrg.example.com/entities_certs.sh
