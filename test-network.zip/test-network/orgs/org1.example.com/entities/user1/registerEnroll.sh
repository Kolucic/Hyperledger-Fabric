#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../../fabric-ca-client
set -x
fabric-ca-client register --id.name user1 --id.secret user1pw --caname ca-org1 --id.type client --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

set -x
fabric-ca-client enroll -u https://user1:user1pw@localhost:7054  -M ../entities/user1/msp --tls.certfiles ../fabric-ca-server/tls-cert.pem 
set +x

