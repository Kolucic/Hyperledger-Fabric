#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../../fabric-ca-client
set -x
fabric-ca-client register --id.name org1admin --id.secret org1adminpw --caname ca-org1 --id.type admin --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

set -x
fabric-ca-client enroll -u https://org1admin:org1adminpw@localhost:7054  -M ../entities/org1admin/msp --tls.certfiles ../fabric-ca-server/tls-cert.pem 
set +x

