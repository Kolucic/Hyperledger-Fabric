#!/bin/bash
cd $(dirname $0)
docker-compose -f ./fabric-ca-server/docker-compose.yaml up -d
sleep 2
bash ./script/registerEnroll.sh
bash ./entities/peer0/registerEnroll.sh
bash ./entities/user1/registerEnroll.sh
bash ./entities/org2admin/registerEnroll.sh
docker-compose -f ./fabric-ca-server/docker-compose.yaml down
bash ./script/connection-profile.sh
