#!/bin/bash
cd $(dirname $0)
function one_line_pem {
    echo "`awk 'NF {sub(/\\n/, ""); printf "%s\\\\\\\n",$0;}' $1`"
}
function json_ccp {
    local CP=$(one_line_pem $1)
    sed -e "s#\${CAPEM}#$CP#" -e "s#\${CAPEM}#$CP#"  ../connection-profile.yaml
}
CAPEM=../fabric-ca-server/ca-cert.pem
echo "$(json_ccp $CAPEM)" > ../connection-profile.yaml