#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../fabric-ca-client
set -x
fabric-ca-client enroll -u https://admin:adminpw@localhost:8054 --caname ca-org2 --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x
