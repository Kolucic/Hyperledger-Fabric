#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../../fabric-ca-client
set -x
fabric-ca-client register --id.name org2admin --id.secret org2adminpw --caname ca-org2 --id.type admin --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

set -x
fabric-ca-client enroll -u https://org2admin:org2adminpw@localhost:8054  -M ../entities/org2admin/msp --tls.certfiles ../fabric-ca-server/tls-cert.pem 
set +x

