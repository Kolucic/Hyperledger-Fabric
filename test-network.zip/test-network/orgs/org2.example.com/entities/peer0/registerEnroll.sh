#!/bin/bash
cd $(dirname $0)
export FABRIC_CA_HOME=../../fabric-ca-client
set -x
fabric-ca-client register --id.name peer0 --id.secret peer0pw --caname ca-org2 --id.type peer --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

set -x
fabric-ca-client enroll -u https://peer0:peer0pw@localhost:8054 --csr.hosts peer0.org2.example.com --csr.hosts localhost -M ../entities/peer0/msp --tls.certfiles ../fabric-ca-server/tls-cert.pem 
set +x

set -x
fabric-ca-client enroll -u https://peer0:peer0pw@localhost:8054 --csr.hosts peer0.org2.example.com --csr.hosts localhost -M ../entities/peer0/tls --enrollment.profile tls --tls.certfiles ../fabric-ca-server/tls-cert.pem
set +x

cp ./tls/tlscacerts/*  ./tls/ca.crt
cp ./tls/signcerts/* ./tls/server.crt
cp ./tls/keystore/* ./tls/server.key
mkdir -p ./msp/tlscacerts
cp ./tls/tlscacerts/* ./msp/tlscacerts/tls-localhost-8054-ca-org2.pem
mkdir ./tls/tlscacerts
cp ./tls/tlscacerts/* ./tls/tlscacerts/tls-localhost-8054-ca-org2.pem
mkdir ./ca
cp ./msp/cacerts/* ./ca/tls-localhost-8054-ca-org2.pem

