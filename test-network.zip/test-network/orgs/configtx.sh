#!/bin/bash
cd $(dirname $0)
configtxgen -configPath . -profile system-channel -channelID system-channel -outputBlock ./system-genesis-block/genesis.block
cp ./system-genesis-block/genesis.block ./ordererOrg.example.com/entities/orderer/system-genesis-block/genesis.block
configtxgen -configPath . -profile mychannel -outputCreateChannelTx ./mychannel/mychannel.tx -channelID mychannel
configtxgen -configPath . -profile mychannel -outputAnchorPeersUpdate ./mychannel/org1.example.com-anchor.tx -channelID mychannel -asOrg org1examplecom
configtxgen -configPath . -profile mychannel -outputAnchorPeersUpdate ./mychannel/org2.example.com-anchor.tx -channelID mychannel -asOrg org2examplecom

